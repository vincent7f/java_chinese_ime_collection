package org.javachineseime.ime.common;

/**
 * @author luosheng 2006/9/25
 *         <ul>
 *         <li> msn:luosheng_lqdnnl@hotmail.com
 *         <li>
 *         </ul>
 * 
 */
public class IMEISN {

	public final static String	CHINESE_PY_WORDS	= "CHINESE-PY-WORDS.txt";
	public final static String	CHINESE_PY			= "CHINESE-PY.txt";
	public final static String	CHINESE_CJ			= "CHINESE-CJ.txt";
	public final static String	CHINESE_WB86		= "CHINESE-WB86.txt";
	public final static String	CHINESE_WB86_WORDS	= "CHINESE-WB86-WORDS.txt";
	public final static String	SIMPLE_COMPLEX		= "SIMPLE-COMPLEX.txt";

}
