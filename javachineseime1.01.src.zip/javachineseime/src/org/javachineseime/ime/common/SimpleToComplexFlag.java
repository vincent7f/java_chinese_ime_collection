/*
 * Created on 2006-2-23
 *
 * 
 */
package org.javachineseime.ime.common;

/**
 * @author luosheng 2006/9/25
 *         <ul>
 *         <li> msn:luosheng_lqdnnl@hotmail.com
 *         <li>
 *         </ul>
 * 
 */
public class SimpleToComplexFlag {

	public static final int	NO					= 0;	// ��ת��
	public static final int	COMPLEX_TO_SIMPLE	= 1;	// ��ת��
	public static final int	SIMPLE_TO_COMPLEX	= 2;	// ��ת��

}
