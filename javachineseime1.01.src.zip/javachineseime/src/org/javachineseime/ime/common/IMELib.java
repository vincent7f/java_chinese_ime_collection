package org.javachineseime.ime.common;

import java.util.List;

/**word libarary*/
public interface IMELib {

    /** 
     * return ALL list<String> 
     */
    List find(String imeInCode);

}
