package swing;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.SystemColor;
import java.awt.Toolkit;

import javax.swing.JPanel;
import javax.swing.JTextPane;

public class FmSqlEditor extends javax.swing.JFrame {

	private JTextPane jTextPane = null;
	private JPanel jContentPane1 = null;
    
	
	public void setVisible(boolean b) {
        if (b == true) {      
            Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
            Dimension frameSize = this.getSize();
            if (frameSize.height > screenSize.height) {
                frameSize.height = screenSize.height;
            }
            if (frameSize.width > screenSize.width) {
                frameSize.width = screenSize.width;
            }
            this.setLocation((screenSize.width - frameSize.width) / 2,
                    (screenSize.height - frameSize.height) / 2);
        }
        super.setVisible(b);
    }
    
	
	
	
	
	/**
	 * This method initializes jTextPane	
	 * 	
	 * @return javax.swing.JTextPane	
	 */
	private JTextPane getJTextPane() {
		if (jTextPane == null) {
			jTextPane = new JTextPane();
			jTextPane.setBackground(SystemColor.info);
		}
		return jTextPane;
	}



	/**
	 * This method initializes jContentPane1	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJContentPane1() {
		if (jContentPane1 == null) {
			jContentPane1 = new JPanel();
			jContentPane1.setLayout(new BorderLayout());
			jContentPane1.add(getJTextPane(), BorderLayout.CENTER);
		}
		return jContentPane1;
	}



	/**
	 * @param args
	 */
	public static void main(String[] args) {
		FmSqlEditor fm = new FmSqlEditor();
		fm.setVisible(true);
	}

	/**
	 * This is the default constructor
	 */
	public FmSqlEditor() {
		super();
		initialize();
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setSize(486, 322);
		this.setContentPane(getJContentPane1());
		this.setTitle("0x7D3B");
		this.addWindowListener(new java.awt.event.WindowAdapter() {
			public void windowClosed(java.awt.event.WindowEvent e) {
				System.exit(0);
			}
		});
	}

	
} 
